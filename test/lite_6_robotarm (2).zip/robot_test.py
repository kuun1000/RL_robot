import pybullet as p
import pybullet_data
import os
import math
import numpy as np

p.connect(p.GUI)
p.resetDebugVisualizerCamera(cameraDistance=1.5, cameraYaw=0, cameraPitch=-20, cameraTargetPosition=[0.55,-0.35,0.1])
p.setGravity(0,0,-9.8)
pi = math.pi
#panda : 7dof arm
# arm = p.loadURDF(os.path.join(pybullet_data.getDataPath(),"franka_panda/panda.urdf"),useFixedBase=True)
cubeStartPos = [0,0,0]
cubeStartOrientation = p.getQuaternionFromEuler([0,0,-pi/2])

arm = p.loadURDF("lite_6_robotarm.urdf",cubeStartPos, cubeStartOrientation, 
                   # useMaximalCoordinates=1, ## New feature in Pybullet
                   flags=p.URDF_USE_INERTIA_FROM_FILE,useFixedBase=True)
table = p.loadURDF(os.path.join(pybullet_data.getDataPath(),"table/table.urdf"),basePosition=[0.5,0,-0.67])
tray = p.loadURDF(os.path.join(pybullet_data.getDataPath(),"tray/tray.urdf"),basePosition=[0.65,0,0])

state_durations = [1,1,1,1]
control_dt = 1./300.    #200fps
p.setTimestep = control_dt
state_t = 0.
current_state = 0

#camera setting(fov:시야각, aspect:종횡비)
fov, aspect, near, far = 60, 1.0, 0.01, 100
projection_matrix = p.computeProjectionMatrixFOV(fov, aspect, near, far)    #카메라 시점, 원근감 표현

useRealTimeSimulation = 1
p.setRealTimeSimulation(useRealTimeSimulation)

def arm_camera():
    # Center of mass position and orientation (of link-7)
    com_p, com_o, _, _, _, _ = p.getLinkState(arm, 9)

    # com_p = list(com_p)  # Convert tuple to list(수정함)
    # com_p[1] += 0.1  #  y-coordinate(수정함)

    rot_matrix = p.getMatrixFromQuaternion(com_o)
    rot_matrix = np.array(rot_matrix).reshape(3, 3)
    # Initial vectors
    init_camera_vector = (0, 0, -1) # z-axis
    init_up_vector = (0, 1, 0) # y-axis
    # Rotated vectors
    camera_vector = rot_matrix.dot(init_camera_vector)
    up_vector = rot_matrix.dot(init_up_vector)
    view_matrix = p.computeViewMatrix(com_p, com_p + 0.1 * camera_vector, up_vector)    #카메라 위치, 방향을 이동
    img = p.getCameraImage(1000, 1000, view_matrix, projection_matrix)
    return img


while True:
    p.configureDebugVisualizer(p.COV_ENABLE_SINGLE_STEP_RENDERING) 
    p.setJointMotorControl2(arm, 0, 
                        p.POSITION_CONTROL,0)
    p.setJointMotorControl2(arm, 1, 
                        p.POSITION_CONTROL,-0.4)
    p.setJointMotorControl2(arm, 2, 
                        p.POSITION_CONTROL,0.5)

    p.stepSimulation()
    arm_camera()